第45轮 Windows PG18 备份工具
D盘空间足够、关闭VPN可打开Render均已确认。
现在只下载并解压到 D:\AI-Agent-Research-Platform。不要运行脚本、安装软件或修改Render，后续逐步指导。
工具已在Linux PowerShell与本地合成PG18测试；原生Windows和真实备份尚未执行。
请阅读 tools/windows-render-backup/README-WINDOWS.md。
