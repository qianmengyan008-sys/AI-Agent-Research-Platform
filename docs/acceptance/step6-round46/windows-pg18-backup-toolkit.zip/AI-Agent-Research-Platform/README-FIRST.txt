第46轮：R1/R2本地修复验收通过，原生Windows尚未验收。
包内AI-Agent-Research-Platform对应D:\AI-Agent-Research-Platform，保留tools/scripts相对位置。
当前只做Prepare本机预检查，不运行备份、加密或恢复，不修改Render。
PostgreSQL实际bin：D:\postgresql-18.6-5-windows-x64-binaries\pgsql\bin，请使用README中的显式-PgBin命令，不移动官方目录。
此包没有数据库dump、收据、凭据或PG客户端安装包。
